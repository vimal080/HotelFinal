import { AppMessageService } from './common/services/app-message.service';
import { HttpClientModule } from '@angular/common/http';
import { HotelModule } from './hotel/hotel.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HotelModule,
    HttpClientModule
  ],
  providers: [AppMessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
