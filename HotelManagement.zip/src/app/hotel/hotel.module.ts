import { AdminGuard } from './../guard/admin.guard';
import { FooterComponent } from './footer/footer.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HotelRoutingModule } from './hotel-routing.module';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { SignupComponent } from './signup/signup.component';
import { HttpClientModule } from '@angular/common/http';
import { RoomsComponent } from './rooms/rooms.component';
import { LogoutComponent } from './logout/logout.component';
import { FacilitiesComponent } from './facilities/facilities.component';
import { DeluxeComponent } from './deluxe/deluxe.component';
import { ReserveComponent } from './reserve/reserve.component';
import { TwinComponent } from './twin/twin.component';
import { RoyalComponent } from './royal/royal.component';
import { ProfileComponent } from './profile/profile.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { BookingStatusComponent } from './booking-status/booking-status.component';

@NgModule({
  declarations: [HomeComponent,
    LoginComponent,
    HeaderComponent,
    SignupComponent,
    FooterComponent,
    RoomsComponent,
    LogoutComponent,
    FacilitiesComponent,
    DeluxeComponent,
    ReserveComponent,
    TwinComponent,
    RoyalComponent,
    ProfileComponent,
    AboutComponent,
    ContactComponent,
    BookingStatusComponent],
  imports: [
    CommonModule,
    HotelRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    HeaderComponent,
    FooterComponent,
  ],
  providers: [ AdminGuard ]
})
export class HotelModule { }
