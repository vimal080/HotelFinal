import { AuthenticationService } from './../../authentication.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { HotelService } from './../../hotel.service';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { Room } from 'src/app/room';

@Component({
  selector: 'app-deluxe',
  templateUrl: './deluxe.component.html',
  styleUrls: ['./deluxe.component.less']
})
export class DeluxeComponent implements OnInit {

  updatePrice: FormGroup;
  roomDetails: Room;

  constructor(private formBuilder: FormBuilder, private hotelService: HotelService, private loginService: AuthenticationService) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    
    this.hotelService.getRoomList(101)
          .subscribe(data => {
            this.roomDetails = data;
            this.updatePrice = this.formBuilder.group({
              id :  [this.roomDetails.id],
              name: [this.roomDetails.name] ,
              price : [this.roomDetails.price],
              noOfRoom: [this.roomDetails.noOfRoom]
            });
            console.log(this.roomDetails);
          }, error => {
            console.log(error);
          } );

    
      
  }

  onSubmit() {
    console.log(this.updatePrice.value)
    this.hotelService.updatePrice(this.updatePrice.value)
            .subscribe(data => this.reloadData());
  }

}

