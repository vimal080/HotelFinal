import { AuthenticationService } from './../../authentication.service';
import { HotelService } from './../../hotel.service';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { UserInfo } from 'src/app/userInfo';
import { Reserve } from 'src/app/reserve';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.less']
})
export class ProfileComponent implements OnInit {

  userName : string;
  email : string;
  phoneNo : string;
  bookingDetails: Observable<Reserve[]>;

  constructor(private hotelService: HotelService, private loginService: AuthenticationService) { }

  ngOnInit() {
    const userInfo: UserInfo= JSON.parse( localStorage.getItem('userInfo'));
    this.userName = userInfo.firstname+" "+userInfo.lastname;
    this.email = userInfo.email;
    this.phoneNo = userInfo.phonenumber;
    this.getRoomBooking();
  }

  getRoomBooking() {
    this.bookingDetails = this.hotelService.getUserBookingList(this.email);
  }

}
