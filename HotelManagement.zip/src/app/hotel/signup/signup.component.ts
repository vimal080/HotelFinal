import { HotelService } from './../../hotel.service';
import { FormGroup, FormControl, Validators, AbstractControl, FormBuilder } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Account } from 'src/app/account';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.less']
})
export class SignupComponent implements OnInit {

  account: Account = new Account();
  submitted = false;
  accountCreated = false;
  signupForm: FormGroup;
  constructor(private formBuilder: FormBuilder, private hotelService: HotelService) { }

  ngOnInit() {
    this.signupForm = this.formBuilder.group({
      firstname: ['', [Validators.required]],
      lastname: [''],
      phonenumber: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmpassword: ['', [Validators.required]]
    });
  }

  newAccount(): void {
    this.submitted = false;
    this.account = new Account();
  }

  save() {
    console.log(this.signupForm.value);
    this.account = this.signupForm.value;
    this.account.role = "user";
    console.log(this.account);
    this.hotelService.createNewAccount(this.account)
      .subscribe(data => { this.accountCreated=true; }, error =>{ alert("Account Haven't Created Please Register again")});
    this.accountCreated= true;
    this.account = new Account();
  }

  onSubmit() {
    this.submitted = true;
    console.log(this.signupForm.value);
    this.save();
  }

 
}
