import { AdminGuard } from './../guard/admin.guard';
import { ProfileComponent } from './profile/profile.component';
import { BookingStatusComponent } from './booking-status/booking-status.component';
import { AboutComponent } from './about/about.component';
import { TwinComponent } from './twin/twin.component';
import { ReserveComponent } from './reserve/reserve.component';
import { LogoutComponent } from './logout/logout.component';
import { RoomsComponent } from './rooms/rooms.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FacilitiesComponent } from './facilities/facilities.component';
import { DeluxeComponent } from './deluxe/deluxe.component';
import { combineLatest } from 'rxjs';
import { RoyalComponent } from './royal/royal.component';
import { ContactComponent } from './contact/contact.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent},
  { path: 'login', component: LoginComponent},
  { path: 'logout', component: LogoutComponent},
  { path: 'facilities', component: FacilitiesComponent},
  { path: 'signup', component: SignupComponent},
  { path: 'rooms', component: RoomsComponent},
  { path: 'reserve', component: ReserveComponent},
  { path: 'deluxe', component: DeluxeComponent},
  { path: 'twin', component: TwinComponent},
  { path: 'royal', component: RoyalComponent},
  { path: 'about', component: AboutComponent},
  { path: 'bookingList', component: BookingStatusComponent, canActivate: [AdminGuard]},
  { path: 'contact', component: ContactComponent},
  { path: 'profile', component: ProfileComponent},
  { path: '', redirectTo: 'home', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HotelRoutingModule { }
