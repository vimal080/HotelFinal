import { Room } from 'src/app/room';
import { AuthenticationService } from './../../authentication.service';
import { HotelService } from './../../hotel.service';
import { Reserve } from './../../reserve';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { UserInfo } from 'src/app/userInfo';

@Component({
  selector: 'app-reserve',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.less']
})
export class ReserveComponent implements OnInit {

  reserve: Reserve = new Reserve();
  updateRoom: FormGroup;
  remainingRooms: Room;
  submitted = false;
  roomBooked = false
  reserveForm: FormGroup;
  bookingRoom: number;
  deluxe: string = 'Deluxe Room';
  twin: string = 'Twin Room';

  constructor(private formBuilder: FormBuilder, private hotelService: HotelService, private authenticationService: AuthenticationService) { }

  ngOnInit() {

    this.createReserveForm(this.reserveForm);
 
  }

  createReserveForm(form: FormGroup) {
    this.reserveForm = this.formBuilder.group ({
      firstname: ['', [Validators.required]],
      lastname: [],
      phonenumber: ['',[Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      email: ['', [Validators.required, Validators.email]],
      room: ['',Validators.required],
      checkindate: ['', Validators.required],
      checkoutdate: ['', Validators.required],
      noOfRoom: ['', Validators.required],
      adult: ['', Validators.required],
      child: ['']
      });

      const userInfo: UserInfo= JSON.parse( localStorage.getItem('userInfo'));
      if(userInfo) {
        this.reserveForm.controls['firstname'].patchValue(userInfo.firstname);
        this.reserveForm.controls['lastname'].patchValue(userInfo.lastname);
        this.reserveForm.controls['phonenumber'].patchValue(userInfo.phonenumber);
        this.reserveForm.controls['email'].patchValue(userInfo.email);
      }

  }

  newReserve(): void {
    this.submitted = false;
    this.reserve = new Reserve();
  }

  save() {
    console.log(this.reserveForm.value);
    this.reserve = this.reserveForm.value;
    this.reserve.bookingDate= new Date();
    console.log(this.reserve);
    console.log(this.reserve.room);
    if(this.reserve.room === 'Deluxe Room')
    {
      console.log('Deluxe Room');
        this.hotelService.getRoomList(101)
            .subscribe(data => { this.remainingRooms = data; 
            this.saveBooking();});
    }
    else if(this.reserve.room === 'Twin Room')
    {
      console.log('Twin Room');
      this.hotelService.getRoomList(102)
              .subscribe(data => { this.remainingRooms = data;
                this.saveBooking();
                console.log(data);});
    }
    else {
      console.log('Royal Room');
      this.hotelService.getRoomList(103)
              .subscribe(data => { this.remainingRooms = data;
              this.saveBooking() });
    }
    

    
  }

  saveBooking() {
    console.log(this.remainingRooms.noOfRoom);
    console.log(this.reserve.noOfRoom);
    console.log('After Update :');
    this.bookingRoom = (this.remainingRooms.noOfRoom - this.reserve.noOfRoom);
    if(this.bookingRoom > 0 ) {
    this.hotelService.bookRoom(this.reserve)
      .subscribe(data => {this.roomBooked = true ;
        this.updateRoom = this.formBuilder.group({
          id :  [this.remainingRooms.id],
          name: [this.remainingRooms.name] ,
          price : [this.remainingRooms.price],
          noOfRoom: [this.bookingRoom]
        });
        this.hotelService.updatePrice(this.updateRoom.value)
            .subscribe(data => console.log(data));
      }, error =>{ alert("Booking Failed . Try again....") });
    this.reserve = new Reserve();
    }
    else {
      alert("Only "+ this.remainingRooms.noOfRoom + "Available....");
    }
  }

  onSubmit() {
    this.submitted = true;
    console.log(this.reserveForm.value);
    this.save();
  }

}
