import { AppMessageService } from './../../common/services/app-message.service';
import { ReloadService } from './../../reload.service';
import { HotelService } from './../../hotel.service';
import { AuthenticationService } from './../../authentication.service';
import { Component, OnInit } from '@angular/core';
import {  FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  invalidLogin = false;

  constructor(private router: Router, private loginservice: AuthenticationService, private hotelService: HotelService, private reloadService: ReloadService, private appMessageService: AppMessageService) { }

  ngOnInit() {
    this.loginForm = new FormGroup({
            username: new FormControl(null, [Validators.required, Validators.minLength(6)]),
            password: new FormControl(null, [Validators.required])
    });
  }

  getUserData(username: string) {
      this.hotelService.getUserByEmail(username)
          .subscribe(data => {
            this.checkLogin(data);
          })
  }

  checkLogin(loginData: object) {
    console.log(this.loginForm.controls['username'].value);
    if (this.loginservice.authenticate(this.loginForm.controls['username'].value, this.loginForm.controls['password'].value, loginData)) {
      this.appMessageService.setHeaderSubject(true);
      this.router.navigate(['/home']);
      this.invalidLogin = false;
    } 
    else {
      alert("Please Enter Correct Username and Password");
      this.invalidLogin = true;
    }
  }

  onSubmit() {
    console.log(this.loginForm.value);
    console.log(this.loginForm.controls['username'].value);
    this.getUserData(this.loginForm.controls['username'].value);
  // }
  }


}
