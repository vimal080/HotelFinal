import { ReloadService } from './../../reload.service';
import { AppMessageService } from './../../common/services/app-message.service';
import { AuthenticationService } from './../../authentication.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit {

  userName: string ;

  constructor(private loginService: AuthenticationService, private appMessageService: AppMessageService) {
           
   }

  ngOnInit() {
    this.userName=localStorage.getItem('firstName');
    this.appMessageService.getHeaderSubject$()
    .subscribe(data =>
      { this.userName=localStorage.getItem('firstName'); });
  }

}
