import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TwinComponent } from './twin.component';

describe('TwinComponent', () => {
  let component: TwinComponent;
  let fixture: ComponentFixture<TwinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TwinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TwinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
