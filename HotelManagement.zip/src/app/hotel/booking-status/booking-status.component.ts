import { HotelService } from './../../hotel.service';
import { Component, OnInit } from '@angular/core';
import { Reserve } from 'src/app/reserve';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-booking-status',
  templateUrl: './booking-status.component.html',
  styleUrls: ['./booking-status.component.less']
})
export class BookingStatusComponent implements OnInit {

  bookingDetails: Observable<Reserve[]>;

  constructor(private hotelService: HotelService) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.bookingDetails = this.hotelService.getBookingList();
  }
}
