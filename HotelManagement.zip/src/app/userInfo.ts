export interface UserInfo {
    id: number;
    firstname: string;
    lastname: string;
    email: string;
    phonenumber: string;
    password: string;
    confirmpassword: string;
}