// start:ng42.barrel
export * from './app-routing.module';
export * from './app.component';
export * from './app.module';
// end:ng42.barrel

