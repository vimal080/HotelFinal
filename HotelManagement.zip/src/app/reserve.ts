export class Reserve {
    firstname : string;
    lastname : string;
    phonenumber : string;
    email: string;
    room: string;
    checkindate: string;
    checkoutdate: string;
    noOfRoom: number;
    adult: number;
    child: number;
    bookingDate?: Date;
}