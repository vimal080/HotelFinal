import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable()
export class AppMessageService {

    headerSubject = new Subject<boolean>();
    constructor() { };

    getHeaderSubject$(): Observable<boolean> {
        return this.headerSubject.asObservable();
    }

    setHeaderSubject(enable: boolean): void {
        this.headerSubject.next(enable);
    }

}