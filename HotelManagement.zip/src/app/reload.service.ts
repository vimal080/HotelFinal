import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReloadService {

  constructor() { }

  private userDetailSource = new Subject<string>();

  userDetail$ = this.userDetailSource.asObservable();

  userProfile() {
    this.userDetailSource.next();
  }


}
