import { UserInfo } from './userInfo';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {



  constructor() { }

  authenticate(username, password, loginData) {
    
    if(loginData){
    if(username === loginData['email'] && password === loginData['password']) {
      localStorage.setItem('userInfo', JSON.stringify(loginData));
      localStorage.setItem('username',username);
      localStorage.setItem('firstName',loginData['firstname']);
      localStorage.setItem('role',loginData['role']);
      console.log(username);
      return true;
    } else {
      console.log(loginData);
      console.log(username);
      console.log('123')
      return false;
    }
    }
  }

  isUser() {
    if(localStorage) {
    let role= localStorage.getItem('role');
    return ( role === "user");
    }
  }

  isUserLoggedIn() {
    let user = localStorage.getItem('username');
    return !( user === null );
  }

  logOut() {
    localStorage.clear();
  }
}
