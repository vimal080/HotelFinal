
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HotelService {

  private baseUrl = 'http://localhost:8080/api/hotel';

  constructor(private http: HttpClient) { }

  createNewAccount(account: object): Observable<object> {
    
    return this.http.post(`${this.baseUrl}`+ `/createuser`, account);
  }

  getUserByEmail(email: string): Observable<Account> {
    return this.http.get<Account>(`${this.baseUrl}` + '/login' + `/${email}`);
  }

  bookRoom(reserve: object): Observable<object> {
    return this.http.post(`${this.baseUrl}`+ `/booking`, reserve)
  }

  getBookingList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+ `/bookingDetails`);
  }

  updatePrice(priceUpdate: object) : Observable<any> {
    console.log(priceUpdate);
    return this.http.put(`${this.baseUrl}`+ `/updatePrice`, priceUpdate);
  }

  getRoomList(id: number): Observable<any> {
    console.log(id);
    return this.http.get(`${this.baseUrl}`+ `/roomDetails` + `/${id}`);
  }

  getUserBookingList(email: string): Observable<any> {
    return this.http.get(`${this.baseUrl}`+ `/userBookingDetails` + `/${email}`);
  }
}
