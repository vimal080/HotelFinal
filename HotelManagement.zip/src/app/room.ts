export class Room {
    id: number;
    name: string;
    price: number;
    noOfRoom: number;
}