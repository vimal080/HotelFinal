package com.example.HotelManagement.controller;

import com.example.HotelManagement.Repository.AccountRepository;
import com.example.HotelManagement.Repository.ReserveRepository;
import com.example.HotelManagement.Repository.RoomRepository;
import com.example.HotelManagement.exception.ResourceNotFoundException;
import com.example.HotelManagement.model.Account;
import com.example.HotelManagement.model.Reserve;
import com.example.HotelManagement.model.Room;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin (origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class HotelController {

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    ReserveRepository reserveRepository;

    @Autowired
    RoomRepository roomRepository;

    @PostMapping(value = "/user")
    public Account createAccount(@RequestBody Account account) {
        System.out.println(account);
        Account newAccount= accountRepository.save(new Account(account.getFirstName(),account.getLastName(),account.getEmail(),account.getPhoneNumber(),account.getPassword(),account.getRole()));
        return  newAccount;
    }

    @GetMapping("/login/{email}")
    public ResponseEntity<Account> getAccountByEmail(@PathVariable("email") String email) throws ResourceNotFoundException {
        System.out.println("Getting Employee Details of->"+email);

        Account verifyAccount = accountRepository.findByEmail(email);
         if(verifyAccount == null) {
            throw new ResourceNotFoundException("No Records found for this email id....");
         }
        return new ResponseEntity(verifyAccount, HttpStatus.OK);
    }

    @PostMapping(value= "/book")
    public Reserve bookRoom(@RequestBody Reserve reserve) {
        System.out.println(reserve);
        System.out.println(reserve.toString());
        Reserve newBook= reserveRepository.save(new Reserve(reserve.getFirstName(),reserve.getLastName(),reserve.getEmail(),reserve.getPhoneNumber(),reserve.getRoom(),reserve.getCheckInDate(),reserve.getCheckOutDate(),reserve.getNoOfRoom(),reserve.getAdult(),reserve.getBookingDate(),reserve.getChild()));
        System.out.println(reserve.toString());
        return newBook;
    }

    @GetMapping("/reservations")
    public List<Reserve> getAllReserves() {
        List<Reserve> reserves= new ArrayList<>();
        reserveRepository.findAll().forEach(reserves::add);
        return reserves;
    }

    @GetMapping("/room")
    public List<Room> getAllRoom() {
        List<Room> rooms= new ArrayList<>();
        roomRepository.findAll().forEach(rooms::add);
        return rooms;
    }

    @GetMapping("/room/{id}")
    public Optional<Room> getRoomDetails(@PathVariable("id") Long id) {
        System.out.println("Getting Employee Details of->"+id);
        return roomRepository.findById(id);
    }

    @GetMapping("/reservations/{email}")
    public List<Reserve> getAllUserBooking(@PathVariable("email") String email) {
        System.out.println("Getting User Details of->"+email);
        return reserveRepository.findByEmail(email);
    }

    @PutMapping("/room/update")
    public void updatePrice(@RequestBody Room room){
        System.out.println(room.getId());
        roomRepository.save(room);
    }

}
