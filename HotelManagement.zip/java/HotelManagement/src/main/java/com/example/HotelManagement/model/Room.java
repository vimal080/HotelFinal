package com.example.HotelManagement.model;

import javax.persistence.*;

@Entity
@Table(name="room")
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name="name")
    private String name;

    @Column(name = "price")
    private  int price;

    @Column(name = "available")
    private int noOfRoom;

    public Room(String name, int price, int noOfRoom) {
        this.name = name;
        this.price = price;
        this.noOfRoom = noOfRoom;
    }

    public Room(long id, String name, int price, int noOfRoom) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.noOfRoom = noOfRoom;
    }

    public Room() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getNoOfRoom() {
        return noOfRoom;
    }

    public void setNoOfRoom(int noOfRoom) {
        this.noOfRoom = noOfRoom;
    }

    @Override
    public String toString() {
        return "Room{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", noOfRoom=" + noOfRoom +
                '}';
    }
}

