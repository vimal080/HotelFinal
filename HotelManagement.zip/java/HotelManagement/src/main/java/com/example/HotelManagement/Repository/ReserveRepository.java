package com.example.HotelManagement.Repository;

import com.example.HotelManagement.model.Reserve;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReserveRepository extends JpaRepository<Reserve, Long> {
    List<Reserve> findByEmail(String email);
}
