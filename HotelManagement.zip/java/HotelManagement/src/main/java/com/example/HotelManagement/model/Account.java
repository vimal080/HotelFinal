package com.example.HotelManagement.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table (name="account")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotNull (message = "First Name is Required")
    @Column (name="firstName")
    private String firstName;

    @Column (name= "lastName")
    private String lastName;

    @NotNull (message = "Email is Required")
    @Column (name= "email")
    private String email;

    @NotNull (message = "Phone Number is Required")
    @Column (name= "phoneNumber")
    private String phoneNumber;

    @NotNull (message = "Password is Required")
    @Column (name = "password")
    private String password;

    @NotNull (message = "Role is Required")
    @Column (name = "role")
    private String role;

    public Account() {
    }

    public Account(@NotNull(message = "First Name is Required") String firstName, String lastName, @NotNull(message = "Email is Required") String email, @NotNull(message = "Phone Number is Required") String phoneNumber, @NotNull(message = "Password is Required") String password, @NotNull(message = "Role is Required") String role) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.role = role;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", password='" + password + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
