package com.example.HotelManagement.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Date;


@Entity
@Table(name="reserve")
public class Reserve {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotNull (message = "First Name is Required")
    @Column(name="firstName")
    private String firstName;

    @Column (name= "lastName")
    private String lastName;

    @NotNull
    @Column (name= "email")
    private String email;

    @NotNull (message = "Phone Number is Required")
    @Column (name= "phoneNumber")
    private String phoneNumber;

    @NotNull (message = "Room Type is Required")
    @Column (name= "roomType")
    private String room;

    @NotNull (message = "Check-In-Date is Required")
    @Column (name= "checkInDate")
    private String checkInDate;

    @NotNull (message = "Check-out-Date is Required")
    @Column (name= "checkOutDate")
    private String checkOutDate;

    @NotNull (message = "No Of Room is Required")
    @Column (name = "noOfRooms")
    private int noOfRoom;

    @NotNull (message = "No of person is Required")
    @Column (name = "Adult")
    private int adult;

    @NotNull (message = "Booking Date is Required")
    @Column (name= "bookingDate")
    private String bookingDate;

    @Column (name = "Child")
    private int child;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Reserve() {
    }

    public Reserve(@NotNull(message = "First Name is Required") String firstName, String lastName, @NotNull String email, @NotNull(message = "Phone Number is Required") String phoneNumber, @NotNull(message = "Room Type is Required") String room, @NotNull(message = "Check-In-Date is Required") String checkInDate, @NotNull(message = "Check-out-Date is Required") String checkOutDate, @NotNull(message = "No Of Room is Required") int noOfRoom, @NotNull(message = "No of person is Required") int adult, @NotNull(message = "Booking Date is Required") String bookingDate, int child) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.noOfRoom = noOfRoom;
        this.adult = adult;
        this.bookingDate = bookingDate;
        this.child = child;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(String checkInDate) {
        this.checkInDate = checkInDate;
    }

    public String getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public int getNoOfRoom() {
        return noOfRoom;
    }

    public void setNoOfRoom(int noOfRoom) {
        this.noOfRoom = noOfRoom;
    }

    public int getAdult() {
        return adult;
    }

    public void setAdult(int adult) {
        this.adult = adult;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public int getChild() {
        return child;
    }

    public void setChild(int child) {
        this.child = child;
    }

    @Override
    public String toString() {
        return "Reserve{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", room='" + room + '\'' +
                ", checkInDate='" + checkInDate + '\'' +
                ", checkOutDate='" + checkOutDate + '\'' +
                ", noOfRoom=" + noOfRoom +
                ", adult=" + adult +
                ", bookingDate='" + bookingDate + '\'' +
                ", child=" + child +
                '}';
    }
}
