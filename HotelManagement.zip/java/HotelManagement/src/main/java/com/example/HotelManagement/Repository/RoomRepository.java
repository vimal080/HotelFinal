package com.example.HotelManagement.Repository;

import com.example.HotelManagement.model.Reserve;
import com.example.HotelManagement.model.Room;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RoomRepository extends JpaRepository<Room, Long> {
    @Override
    Optional<Room> findById(Long aLong);
}
